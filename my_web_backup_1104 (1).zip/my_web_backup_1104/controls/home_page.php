<?php


// include template
include 'templates/home_page.tpl.php';

?>