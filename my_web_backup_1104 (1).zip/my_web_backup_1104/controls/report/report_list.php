<?php
	
// include template
include "templates/{$module}/{$module}_list.tpl.php";

?>